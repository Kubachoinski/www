from django.contrib import admin
from pogotowieapp.models import *
admin.site.register(Dyspozytorzy)
admin.site.register(Ratownicy)
admin.site.register(Zgloszenia)