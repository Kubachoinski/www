from django.apps import AppConfig


class OglappConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'oglapp'
