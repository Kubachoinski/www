from django.contrib import admin
from .models import Uzytkownik, Ogloszenia

admin.site.register(Uzytkownik)
admin.site.register(Ogloszenia)
